package com.hlag.aircargo.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class ProductPrice {

	String name;
	double price;
	int quantity;

	public ProductPrice(String name, double price, int quantity) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public int getQuantity() {
		return quantity;
	}

}

public class CustomCollectorExample {

	public static void main(String[] args) {
		List<ProductPrice> products = Arrays.asList(
				new ProductPrice("Laptop", 1200, 4),
				new ProductPrice("Mouse", 20, 2),
				new ProductPrice("Keyboard", 50, 3),
				new ProductPrice("Monitor", 200, 6),
				new ProductPrice("Charger", 30, 1));

		Map<String, Double> calculateTotalRevenue = products.stream()
				.collect(
						Collectors.groupingBy(t -> t.getName(), Collectors.summingDouble(t -> t.getPrice() * t.getQuantity())));

		System.out.println("calculateTotalRevenue range: " + calculateTotalRevenue);
	}
}
