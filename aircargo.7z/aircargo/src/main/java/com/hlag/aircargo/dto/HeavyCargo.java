package com.hlag.aircargo.dto;


// Subclass for Heavy Cargo
class HeavyCargo extends Cargo {

	private double extraHandlingFee; // Extra fee for handling heavy cargo

	// Constructor for HeavyCargo
	public HeavyCargo(String cargoId, double weight, double extraHandlingFee) {
		super(cargoId, weight);
		this.extraHandlingFee = extraHandlingFee;
	}

	// Getter and Setter for extraHandlingFee
	public double getExtraHandlingFee() {
		return extraHandlingFee;
	}

	public void setExtraHandlingFee(double extraHandlingFee) {
		this.extraHandlingFee = extraHandlingFee;
	}

	// Overridden method to calculate shipping cost (higher cost due to weight)
	public double calculateShippingCost() {
		double baseCost = super.calculateShippingCost();
		return baseCost + extraHandlingFee; // Additional cost due to weight
	}

}