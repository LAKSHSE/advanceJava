package com.hlag.aircargo.dto;


public class CreditCardPaymentProcessor implements PaymentProcessor {

	@Override
	public boolean ProcessPayment(double amount) {
		// TODO Auto-generated method stub
		if (amount > 0) {
			System.out.println("payment success");
			return true;
		}
		System.out.println("payment failure");
		return false;
	}

	@Override
	public boolean ValidatePayment(String paymentDetails) {
		// TODO Auto-generated method stub
		if (paymentDetails != null && !paymentDetails.isEmpty()) {
			System.out.println("payment details are valid");
			return true;
		}
		System.out.println("payment details are invalid");
		return false;
	}

	@Override
	public String getTransactionStatus(int transactionId) {
		// TODO Auto-generated method stub
		System.out.println("get transactionId" + transactionId);
		return "transaction" + transactionId + "is completed successfully";
	}

}
