package com.hlag.aircargo.repo;

import java.util.Scanner;

import com.hlag.aircargo.dto.CargoClass;
import com.hlag.aircargo.dto.CargoManagementSystem;

public class CargoMainClass {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		CargoManagementSystem cargoSystem = new CargoManagementSystem();
		boolean running = true;

		while (running) {
			System.out.println("\nCargo Management System:");
			System.out.println("1. Add Cargo");
			System.out.println("2. Remove Cargo");
			System.out.println("3. Display Cargo");
			System.out.println("4. Exit");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume newline

			switch (choice) {
				case 1: // Add Cargo
					System.out.print("Enter Cargo ID: ");
					int id = scanner.nextInt();
					scanner.nextLine(); // Consume newline
					System.out.print("Enter Cargo Name: ");
					String name = scanner.nextLine();
					System.out.print("Enter Cargo Weight (kg): ");
					double weight = scanner.nextDouble();
					scanner.nextLine(); // Consume newline
					CargoClass cargo = new CargoClass(id, name, weight);
					cargoSystem.addCargo(cargo);
					break;

				case 2: // Remove Cargo
					System.out.print("Enter Cargo ID to remove: ");
					int removeId = scanner.nextInt();
					cargoSystem.removeCargo(removeId);
					break;

				case 3: // Display Cargo
					cargoSystem.displayCargo();
					break;

				case 4: // Exit
					running = false;
					System.out.println("Exiting the system.");
					break;

				default:
					System.out.println("Invalid choice! Please try again.");
					break;
			}
		}

		scanner.close();
	}

}
