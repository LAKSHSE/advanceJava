package com.hlag.aircargo.dto;

import java.util.ArrayList;
import java.util.Iterator;

public class CargoManagementSystem {

	private ArrayList<CargoClass> cargoList;

	public CargoManagementSystem() {
		cargoList = new ArrayList<>();
	}

	public void addCargo(CargoClass cargoClass) {
		cargoList.add(cargoClass);
		System.out.println("Cargo added:===" + cargoClass);
	}

	public void removeCargo(int cargoId) {
		Iterator<CargoClass> iterator = cargoList.iterator();
		while (iterator.hasNext()) {
			CargoClass cargoClass = iterator.next();
			if (cargoClass.getId() == cargoId) {
				iterator.remove();
				System.out.println("cargo removed===" + cargoClass);
			}
		}
		System.out.println("Cargo with ID " + cargoId + " not found.");
	}

	public void displayCargo() {
		if (cargoList.isEmpty()) {
			System.out.println("No Cargo items in the system====");
		} else {
			System.out.println("List of cargo items==");
			for (CargoClass cargoClass : cargoList) {
				System.out.println(cargoClass);
			}
		}
	}
}
