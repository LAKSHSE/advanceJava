package com.hlag.aircargo.dto;

import java.time.LocalDate;

// Base class Cargo
class Cargo {

	private String cargoId;
	private double weight; // in kilograms

	// Constructor for the Cargo class
	public Cargo(String cargoId, double weight) {
		this.cargoId = cargoId;
		this.weight = weight;
	}

	// Getter and Setter for cargoId
	public String getCargoId() {
		return cargoId;
	}

	public void setCargoId(String cargoId) {
		this.cargoId = cargoId;
	}

	// Getter and Setter for weight
	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	// Method to calculate the basic shipping cost (just weight-based in this case)
	public double calculateShippingCost() {
		return weight * 2.0; // Basic cost: 2 per kg
	}

	@Override
	public String toString() {
		return "Cargo ID: " + cargoId + ", Weight: " + weight + "kg";
	}
	
	public static void main(String[] args) {
		// Creating instances of Cargo types

		// Regular cargo
		Cargo regularCargo = new Cargo("C001", 50); // 50kg cargo
		System.out.println(regularCargo);
		System.out.println("Shipping Cost: " + regularCargo.calculateShippingCost());

		// Perishable cargo
		PerishableCargo perishableCargo = new PerishableCargo("C002", 30, LocalDate.of(2024, 12, 31));
		System.out.println(perishableCargo);
		System.out.println("Shipping Cost: " + perishableCargo.calculateShippingCost());

		// Heavy cargo
		HeavyCargo heavyCargo = new HeavyCargo("C003", 200, 50); // Extra handling fee of 50
		System.out.println(heavyCargo);
		System.out.println("Shipping Cost: " + heavyCargo.calculateShippingCost());
	}
}