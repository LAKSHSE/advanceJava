package com.hlag.aircargo.dto;

import java.time.LocalDate;

// Subclass for Perishable Cargo
class PerishableCargo extends Cargo {

	private LocalDate expirationDate;

	// Constructor for PerishableCargo
	public PerishableCargo(String cargoId, double weight, LocalDate expirationDate) {
		super(cargoId, weight);
		this.expirationDate = expirationDate;
	}

	// Getter and Setter for expirationDate
	public LocalDate getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}

	// Overridden method to calculate shipping cost (higher cost due to refrigeration)
	public double calculateShippingCost() {
		double baseCost = super.calculateShippingCost();
		return baseCost + 10.0; // Extra cost for refrigeration handling
	}

}
