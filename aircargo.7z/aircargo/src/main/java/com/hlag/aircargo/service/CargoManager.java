package com.hlag.aircargo.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CargoManager {

	private List<Cargo> cargoList;

	public CargoManager(List<Cargo> cargoList) {
		this.cargoList = cargoList;
	}

	// Filter cargo by type
	public List<Cargo> filterByType(String type) {
		return cargoList.stream().filter(cargo -> cargo.getType().equalsIgnoreCase(type)).collect(Collectors.toList());
	}

	// Sort cargo by weight (ascending)
	public List<Cargo> sortByWeight() {
		return cargoList.stream().sorted(Comparator.comparingDouble(Cargo::getWeight)).collect(Collectors.toList());
	}

	// Count cargo by type
	public long countByType(String type) {
		return cargoList.stream().filter(cargo -> cargo.getType().equalsIgnoreCase(type)).count();
	}

	// Get all cargo items
	public List<Cargo> getAllCargo() {
		return cargoList;
	}

	public static void main(String[] args) {
		// Sample cargo data
		List<Cargo> cargoList = new ArrayList<>();
		cargoList.add(new Cargo(1, "Electronics", 200));
		cargoList.add(new Cargo(2, "Clothing", 50));
		cargoList.add(new Cargo(3, "Furniture", 120));
		cargoList.add(new Cargo(4, "Electronics", 300));
		cargoList.add(new Cargo(5, "Clothing", 70));

		CargoManager manager = new CargoManager(cargoList);

		// Filter by type
		System.out.println("Filtered by type (Electronics):");
		manager.filterByType("Electronics").forEach(System.out::println);

		// Sort by weight
		System.out.println("\nSorted by weight:");
		manager.sortByWeight().forEach(System.out::println);

		// Count by type
		System.out.println("\nCount of 'Clothing' items: " + manager.countByType("Clothing"));
	}

}
