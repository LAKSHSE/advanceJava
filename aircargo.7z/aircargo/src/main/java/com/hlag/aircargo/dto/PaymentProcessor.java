package com.hlag.aircargo.dto;


public interface PaymentProcessor {

	boolean ProcessPayment(double amount);

	boolean ValidatePayment(String paymentDetails);

	String getTransactionStatus(int transactionId);

}
