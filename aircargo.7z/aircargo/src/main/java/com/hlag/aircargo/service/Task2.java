package com.hlag.aircargo.service;


public class Task2 {

	public static void main(String[] args) {
		Cargo cargo1 = new Cargo(0, "Electronics", 150);
		Cargo cargo2 = new Cargo(0, "Clothing", 50);

		CargoProcessor printDetails = CargoProcessor::printCargoDetails;
		printDetails.process(cargo1);
		printDetails.process(cargo2);

		CargoProcessor calculateShippingCost = cargo -> {
			double cost = cargo.getWeight() * 0.5; // e.g., $0.5 per kg
			System.out.println("Shipping cost for " + cargo.getType() + ": $" + cost);
		};
		calculateShippingCost.process(cargo1);
		calculateShippingCost.process(cargo2);

		CargoProcessor categorizeCargo = cargo -> {
			if (cargo.getType().equalsIgnoreCase("Electronics")) {
				System.out.println("This is an Electronics cargo.");
			} else if (cargo.getType().equalsIgnoreCase("Clothing")) {
				System.out.println("This is a Clothing cargo.");
			} else {
				System.out.println("Cargo type is unknown.");
			}
		};
		categorizeCargo.process(cargo1);
		categorizeCargo.process(cargo2);
	}
}

@FunctionalInterface
interface CargoProcessor {

	void process(Cargo cargo);

	static void printCargoDetails(Cargo cargo) {
		System.out.println("Cargo type: " + cargo.getType() + ", Weight: " + cargo.getWeight() + " kg");
	}
}