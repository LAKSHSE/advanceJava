
package com.hlag.aircargo.repo;

import com.hlag.aircargo.dto.CreditCardPaymentProcessor;
import com.hlag.aircargo.dto.PaymentProcessor;

public class PaymentClass {

	public static void main(String[] args) {

		PaymentProcessor paymentProcessor = new CreditCardPaymentProcessor();

		double amount = 350.24;
		String paymentDetails = "1234-5678-9876-5432"; // credit card number

		boolean isValid = paymentProcessor.ValidatePayment(paymentDetails);
		if (isValid) {
			boolean processAmount = paymentProcessor.ProcessPayment(amount);
			if (processAmount) {
				String status = paymentProcessor.getTransactionStatus(1234);
				System.out.println(status);
			} else {
				System.out.println("payment process failed");
			}
		} else {
			System.out.println("Invalid payment details. Cannot proceed with the payment.");
		}
	}

	@FunctionalInterface
	interface I5 {

		public boolean test();

		public default void test2() {
			System.out.println("helo from test2");
		}
	}

	class I1Impl implements I5 {

		@Override
		public boolean test() {
			System.out.println("hello from test");
			return true;
		}

		@Override
		public void test2() {
			System.out.println("test2 is overridden");
		}

	}

}
