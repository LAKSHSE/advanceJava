package com.hlag.aircargo.service;

public class Cargo {

	private int id;
	private String type;
	private double weight;

	public Cargo(int id, String type, double weight) {
		this.id = id;
		this.type = type;
		this.weight = weight;
	}

	public int getId() {
		return id;
	}

	public String getType() {
		return type;
	}

	public double getWeight() {
		return weight;
	}

	@Override
	public String toString() {
		return "Cargo{" + "id=" + id + ", type='" + type + '\'' + ", weight=" + weight + '}';
	}
}
