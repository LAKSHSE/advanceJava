package com.testing.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DeliveryMain {

	public static void main(String[] args) {
		List<Delivery> deliveries = Arrays.asList(
		    new Delivery("D1", true, 1.5, 10.0, 50.0),  // Completed
		    new Delivery("D2", false, 2.0, 15.0, 70.0), // Pending
		    new Delivery("D3", true, 1.0, 8.0, 40.0),   // Completed
		    new Delivery("D4", true, 3.0, 20.0, 90.0),  // Completed
		    new Delivery("D5", false, 0.5, 5.0, 20.0),  // Pending
				new Delivery("D6", true, 2.0, 12.0, 80.0)); // Completed

		List<Delivery> updatedDeliveries = deliveries.stream().map(delivery -> {
			if (delivery.isCompleted()) {
				delivery.setCompleted(true);
			}
			return delivery;
		}).collect(Collectors.toList());

		System.out.println("updatedDeliveries::::" + updatedDeliveries);

		List<Delivery> updatedDeliveriesFilter = deliveries.stream().filter(Delivery::isCompleted).map(delivery -> {
			delivery.setCompleted(true);
			return delivery;
		}).collect(Collectors.toList());

		System.out.println("updatedDeliveriesFilter::::" + updatedDeliveriesFilter);

		List<Delivery> remainingDeliveries = deliveries.stream()
				.filter(delivery -> !delivery.isCompleted()) // Keep deliveries that are not "Completed"
				.collect(Collectors.toList());

		System.out.println("remainingDeliveries::::" + remainingDeliveries);
	}
}
