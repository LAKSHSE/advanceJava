package com.testing.test;

public class ExampleLambda {

	public static void main(String[] args) {

		// Test test = (int a, int b) -> a / b;
		// double result = test.divide(14, 7);
		// System.out.println(result);

		// Greeter greeter = (name) -> System.out.println("Hello" + name + "!");
		// greeter.greet("seetha");
		// greeter.greet("Kala");

		EvenOrAdd evenOrAdd = (number) -> {
			if (number % 2 == 0) {
				System.out.println(number + " It is Even");
			}
			else {
				System.out.println(number + " It is Odd");
			}
		};
		evenOrAdd.checkEvenOrAdd(3);
		evenOrAdd.checkEvenOrAdd(2);
	}

}

// @FunctionalInterface
// interface Test {
//
// public int divide(int a, int b);
// }

// @FunctionalInterface
// interface Greeter {
//
// public void greet(String name);
// }

@FunctionalInterface
interface EvenOrAdd {

	public void checkEvenOrAdd(int number);
}
