package com.testing.test;

import java.util.HashMap;
import java.util.Map;

public class MathOperations {

	public static void main(String[] args) {
		MathFunctions mathFunctions = (int a, int b) -> a + b;
		int result = mathFunctions.addOrSubOrDivision(10, 20);
		System.out.println(result);

		MathFunctions mathFunctionsDivide = (int a, int b) -> a / b;
		int resultDivide = mathFunctionsDivide.addOrSubOrDivision(100, 20);
		System.out.println(resultDivide);

		MathFunctions mathFunctionsSubtraction = (int a, int b) -> a - b;
		int resultSubtraction = mathFunctionsSubtraction.addOrSubOrDivision(100, 20);
		System.out.println(resultSubtraction);

		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.put("E", 50);
		map.put("F", 60);
		map.put("G", 70);

		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println("Key: " + entry.getKey() + ",Value: " + entry.getValue());
		}
		
		map.forEach((k, v) -> {
			System.out.println(k + " " + v);
		});
	}
}

@FunctionalInterface
interface MathFunctions
{

	public int addOrSubOrDivision(int a, int b);
}