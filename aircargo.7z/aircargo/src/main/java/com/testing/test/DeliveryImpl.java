package com.testing.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DeliveryImpl implements DeliveryRepo {

	private List<Delivery> deliveries = new ArrayList<>();

	// Save a new delivery
	@Override
	public void save(Delivery delivery) {
		// deliveries.add(delivery);
		double threshold = 50.0;
		List<Delivery> filteredDeliveries = deliveries.stream()
				.filter(deliveryes -> deliveryes.getRevenue() > threshold)
				.collect(Collectors.toList());
		System.out.println("Deliveries with revenue greater than " + threshold + ":");
		filteredDeliveries.forEach(System.out::println);
	}

	// Find a delivery by its ID
	@Override
	public Optional<Delivery> findById(String deliveryId) {
		return deliveries.stream().filter(delivery -> delivery.getDeliveryId().equals(deliveryId)).findFirst();
	}

	// Get all deliveries
	@Override
	public List<Delivery> findAll() {
		return new ArrayList<>(deliveries);
	}

	// Update an existing delivery
	@Override
	public void update(Delivery delivery) {
		Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
		if (existingDelivery.isPresent()) {
			deliveries.remove(existingDelivery.get());
			deliveries.add(delivery);
		}
	}

	// Delete a delivery by its ID
	@Override
	public void deleteById(String deliveryId) {
		deliveries.stream().filter(delivery -> !delivery.isCompleted()).collect(Collectors.toList());
		// deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
	}

	// Get deliveries that are completed
	@Override
	public List<Delivery> findCompletedDeliveries() {
		// List<Delivery> completedDeliveries = new ArrayList<>();
		// for (Delivery delivery : deliveries) {
		// if (delivery.isCompleted()) {
		// completedDeliveries.add(delivery);
		// }
		// }
		return deliveries.stream().filter(e -> e.isCompleted()).collect(Collectors.toList());
	}

	public void updateList(Delivery delivery) {
		List<Boolean> existingDelivery = deliveries.stream()
				.filter(existId -> existId.getDeliveryId().equals(delivery.getDeliveryId()))
				.map(e -> e.isCompleted())
				.collect(Collectors.toList());
		
		List<Boolean> existingDeliveryMap = deliveries.stream()
				.map(existId -> existId.getDeliveryId().equals(existId))
				.collect(Collectors.toList());
	}

	public double calculateTotalRevenue() {
		return deliveries.stream().mapToDouble(e -> e.getRevenue()).sum();
	}

	public double calculateRevenueTime() {
		return deliveries.stream()
				.mapToDouble(e -> e.getDeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new IllegalArgumentException("Data is not found"));
		// .getAsDouble();
	}

	public List<Delivery> calculateTopPerform(int numberLimit) {
		return deliveries.stream()
				.filter(e -> e.isCompleted())
				.sorted((a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(numberLimit)
				.collect(Collectors.toList());
	}

}