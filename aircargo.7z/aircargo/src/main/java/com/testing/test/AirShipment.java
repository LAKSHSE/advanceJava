package com.testing.test;

// Step 1: Define the Shipment interface
interface ShipmentService {

	void deliver();
}

// Step 2: Create concrete classes for different shipment types
class AirShipment implements ShipmentService {

	@Override
	public void deliver() {
		System.out.println("Delivering by air.");
	}

	public static void main(String[] args) {
		// Create different shipments using the factory
		ShipmentService airShipment = ShipmentFactory.createShipment("air");
		ShipmentService seaShipment = ShipmentFactory.createShipment("sea");
		ShipmentService landShipment = ShipmentFactory.createShipment("land");

		// Deliver the shipments
		airShipment.deliver();
		seaShipment.deliver();
		landShipment.deliver();
}
}

class SeaShipment implements ShipmentService {

	@Override
	public void deliver() {
		System.out.println("Delivering by sea.");
	}
}

class LandShipment implements ShipmentService {

	@Override
	public void deliver() {
		System.out.println("Delivering by land.");
	}
}

// Step 3: Create a ShipmentFactory class
class ShipmentFactory {

	// Factory method to create Shipment objects
	public static ShipmentService createShipment(String shipmentType) {
		switch (shipmentType.toLowerCase()) {
			case "air":
				return new AirShipment();
			case "sea":
				return new SeaShipment();
			case "land":
				return new LandShipment();
			default:
				throw new IllegalArgumentException("Invalid shipment type: " + shipmentType);
		}
	}
}

//// Step 4: Demonstrate the Factory Pattern in action
// public class AirShipment {
//
// public static void main(String[] args) {
// // Create different shipments using the factory
// ShipmentService airShipment = ShipmentFactory.createShipment("air");
// ShipmentService seaShipment = ShipmentFactory.createShipment("sea");
// ShipmentService landShipment = ShipmentFactory.createShipment("land");
//
// // Deliver the shipments
// airShipment.deliver();
// seaShipment.deliver();
// landShipment.deliver();
// }
// }