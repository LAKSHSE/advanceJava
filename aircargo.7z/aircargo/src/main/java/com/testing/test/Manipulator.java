package com.testing.test;

import java.util.function.Function;
import java.util.function.IntPredicate;
import java.util.function.UnaryOperator;

public class Manipulator {

	public static void main(String[] args) {
		
		// StringManipulator toUpperCase = (input) -> input.toUpperCase();
		// StringManipulator reverseString = (input) -> new StringBuilder(input).reverse().toString();
		// String testString = "hello";
		// String upperCaseResult = toUpperCase.manipulator(testString);
		// System.out.println("Uppercase: " + upperCaseResult);
		// String reversedString = reverseString.manipulator(testString);
		// System.out.println("Reversed: " + reversedString);


	// }

		Function<String, Integer> function = x -> x.length();
		System.out.println(function.apply("advik"));

		IntPredicate function1 = x -> x % 7 == 0;
		UnaryOperator<String> function2 = x -> x;

		// int result = function.andThen(function2).apply("Seetha");
		System.out.println(function1.test(7));
	}
}

@FunctionalInterface
interface StringManipulator {

	public String manipulator(String name);
}