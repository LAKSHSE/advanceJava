package com.testing.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamSample1 {

	public static void main(String[] args) {

		List<String> words = Arrays
				.asList("apple", "banana", "orange", "date", "seetha", "kala", "water", "biriyani", "tomato", "usa");
		// List<String> result = new ArrayList<>();
		Long startTime = System.currentTimeMillis();
		List<String> result = words.stream()
				.filter(e -> e.length() > 5)
				.map(String::toUpperCase)
				.collect(Collectors.toList());

		// for (String word : words) {
		// if (word.length() > 5) {
		// result.add(word.toUpperCase());
		// }
		// }

		result.stream().forEach(e -> System.out.println(e));
		result.forEach(e -> System.out.println(e));

		Long endTime = System.currentTimeMillis();
		System.out.println("Diffence : " + (startTime - endTime));
		System.out.println(result);
	}
}
