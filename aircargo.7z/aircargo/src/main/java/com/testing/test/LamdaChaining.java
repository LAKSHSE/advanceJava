package com.testing.test;

public class LamdaChaining {

	public static void main(String[] args) {

		Processor add = number -> number + 10;
		Processor multiply = number -> number * 2;
		Processor subtract = number -> number - 2;

		Processor combinedProcessor = add.andThen(multiply).andThen(subtract);
	}
}

@FunctionalInterface
interface Processor
{
	public int process(int number);
}