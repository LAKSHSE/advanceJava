package com.testing.test;

public class LambdaExpressions {

	public static void main(String[] args) {

		// // I5 i5 = new I1Impl();
		// // boolean result = i5.test();
		// // i5.test2();
		//
		// I5 i6 = () -> {
		// System.out.println("hello from lambda");
		// };
		// i6.test();
		// i6.test2();
		//
		// I5 i5 = new I5() {
		//
		// @Override
		// public void test() {
		// // TODO Auto-generated method stub
		// }
		//
		// // @Override
		// // public void test2() {
		// // // TODO Auto-generated method stub
		// // System.out.println("hello from overridden");
		// // }
		// };
		// i5.test2();
		// }

		IOps iops = (int a, int b) -> a + b;
		int res = iops.add(20, 30);
		System.out.println(res);

		demo(iops);
		demo((a, b) -> a + b + 10);

		// IOps iops = new IOps() {
		//
		// @Override
		// public int add(int a, int b) {
		// // TODO Auto-generated method stub
		// return a + b;
		// }
		// };
		// int res = iops.add(10, 20);
		// System.out.println(res);
	}
}

//	@FunctionalInterface
//	interface I5 {
//
//		public void test();
//
//		public default void test2() {
//			System.out.println("helo from test2");
//		}
//	}
//
//	class I1Impl implements I5 {
//
//		@Override
//		public void test() {
//			System.out.println("hello from test");
//		}
//
//		@Override
//		public void test2() {
//			System.out.println("test2 is overridden");
// }}

public static void demo(IOps iops) {
	System.out.println(iops.add(10, 20));
}

@FunctionalInterface
interface IOps{
	public int add(int a,int b);
}

