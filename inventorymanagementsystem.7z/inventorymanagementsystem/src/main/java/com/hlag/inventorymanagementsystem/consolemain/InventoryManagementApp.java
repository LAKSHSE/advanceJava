package com.hlag.inventorymanagementsystem.consolemain;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.service.InventoryService;
import com.hlag.inventorymanagementsystem.service.InventoryServiceImpl;

public class InventoryManagementApp {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		InventoryService service = InventoryServiceImpl.getInstance();

		while (true) {
			// Display the menu
			System.out.println("Inventory Management System:");
			System.out.println("1. Add Product");
			System.out.println("2. View Products");
			System.out.println("3. Update Product");
			System.out.println("4. Delete Product");
			System.out.println("5. Retrive Product With Sorting");
			System.out.println("6. Product Sorted By Price");
			System.out.println("7.  Product Sorted By Name");
			System.out.println("8. Exit");
			System.out.print("Enter your choice (1-5): ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
				case 1: // Add Product
					System.out.print("Enter product name: ");
					String name = scanner.nextLine();
					System.out.print("Enter product description: ");
					String description = scanner.nextLine();
					System.out.print("Enter product price: ");
					double price = scanner.nextDouble();
					System.out.print("Enter product quantity: ");
					int quantity = scanner.nextInt();
					scanner.nextLine();
					Product newProduct = new Product(name, description, price, quantity);
					Product addedProduct = service.addProduct(newProduct);
					System.out.println("Product added with ID: " + addedProduct.getId());
					break;

				case 2: // View Products
					Optional<List<Product>> products = service.getProducts();
					if (products.isPresent() && !products.get().isEmpty()) {
						System.out.println("List of Products:");
						for (Product product : products.get()) {
							System.out.println(product);
						}
					} else {
						System.out.println("No products available.");
					}
					break;

				case 3: // Update Product
					System.out.print("Enter product ID to update: ");
					String updateProductId = scanner.nextLine();
					Optional<Product> existingProduct = service.getProductById(updateProductId);
					if (existingProduct.isPresent()) {
						System.out.print("Enter new product name: ");
						String updatedName = scanner.nextLine();
						System.out.print("Enter new product description: ");
						String updatedDescription = scanner.nextLine();
						System.out.print("Enter new product price: ");
						double updatedPrice = scanner.nextDouble();
						System.out.print("Enter new product quantity: ");
						int updatedQuantity = scanner.nextInt();
						scanner.nextLine();
						Product updatedProduct = new Product(updatedName, updatedDescription, updatedPrice, updatedQuantity);
						service.updateProduct(updateProductId, updatedProduct);
						System.out.println("Product updated.");
					} else {
						System.out.println("Product not found.");
					}
					break;

				case 4: // Delete Product
					System.out.print("Enter product ID to delete: ");
					String deleteProductId = scanner.nextLine();
					boolean deleted = service.deleteProduct(deleteProductId);
					if (deleted) {
						System.out.println("Product deleted successfully.");
					} else {
						System.out.println("Product not found.");
					}
					break;

				case 5:
					// Retrieve products without any sorting
					List<Product> products1 = service.getAllProducts(false, false);
					if (products1.isEmpty()) {
						System.out.println("No products available.");
					} else {
						System.out.println("List of Products:");
						for (Product product : products1) {
							System.out.println(product);
						}
					}
					break;

				case 6:
					// Retrieve products sorted by price
					List<Product> productsByPrice = service.getAllProducts(true, false);
					if (productsByPrice.isEmpty()) {
						System.out.println("No products available.");
					} else {
						System.out.println("List of Products (Sorted by Price):");
						for (Product product : productsByPrice) {
							System.out.println(product);
						}
					}
					break;

				case 7:
					// Retrieve products sorted by name
					List<Product> productsByName = service.getAllProducts(false, true);
					if (productsByName.isEmpty()) {
						System.out.println("No products available.");
					} else {
						System.out.println("List of Products (Sorted by Name):");
						for (Product product : productsByName) {
							System.out.println(product);
						}
					}
					break;

				case 8: // Exit
					System.out.println("Exiting Inventory Management System.");
					scanner.close();
					return;
				default:
					System.out.println("Invalid choice.");
			}
		}
	}
}
