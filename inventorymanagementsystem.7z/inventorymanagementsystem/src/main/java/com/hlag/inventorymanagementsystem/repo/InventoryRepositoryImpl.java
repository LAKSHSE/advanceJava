package com.hlag.inventorymanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public class InventoryRepositoryImpl implements InventoryRepository {

	private List<Product> products = new ArrayList<>();
	private static InventoryRepositoryImpl inventoryRepositoryImpl;

	private InventoryRepositoryImpl() {
	}

	public static InventoryRepositoryImpl getInstance() {
		if (inventoryRepositoryImpl == null) {
			inventoryRepositoryImpl = new InventoryRepositoryImpl();
		}
		return inventoryRepositoryImpl;

	}

	@Override
	public Product addProduct(Product product) {
		return products.add(product) ? product : null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return products.stream().filter(e -> e.getId().toString().equals(id)).findFirst();
	}

	@Override
	public Optional<List<Product>> getProducts() {
		return products.isEmpty() ? Optional.empty() : Optional.of(new ArrayList<>(products));
	}

	@Override
	public boolean deleteProduct(String productID) {
		Optional<Product> product = getProductById(productID);
		if (product.isPresent()) {
			products.remove(product.get());
			return true;
		}
		return false;
	}

	@Override
	public Product updateProduct(String productID, Product updatedProduct) {
		Optional<Product> existingProduct = getProductById(productID);
		if (existingProduct.isPresent()) {
			Product product = existingProduct.get();
			product.setName(updatedProduct.getName());
			product.setDescription(updatedProduct.getDescription());
			product.setPrice(updatedProduct.getPrice());
			product.setQuantity(updatedProduct.getQuantity());
			return product;
		}
		return null;
	}

	@Override
	public List<Product> getProductsSortedByPrice() {
		products.sort((p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
		return products;
	}

	@Override
	public List<Product> getProductsSortedByName() {
		products.sort((p1, p2) -> p1.getName().compareToIgnoreCase(p2.getName()));
		return products;
	}

	@Override
	public List<Product> getAllProduct() {
		return products;
	}
}
