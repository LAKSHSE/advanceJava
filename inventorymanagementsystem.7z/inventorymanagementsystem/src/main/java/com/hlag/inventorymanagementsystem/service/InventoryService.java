package com.hlag.inventorymanagementsystem.service;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public interface InventoryService {

	public Product addProduct(Product product);

	public Optional<Product> getProductById(String id);

	public Optional<List<Product>> getProducts();

	public boolean deleteProduct(String id);

	public Product updateProduct(String id, Product product);

	public List<Product> getAllProducts(boolean sortByPrice, boolean sortByName);
}
