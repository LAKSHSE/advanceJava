package com.hlag.testing.exception;

public class DataNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.getMessage();
	}

	public DataNotFoundException() {
		super();
	}

	public DataNotFoundException(String msg) {
		super(msg);
	}
}
