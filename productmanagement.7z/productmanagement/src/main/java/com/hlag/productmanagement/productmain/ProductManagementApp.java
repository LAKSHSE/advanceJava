package com.hlag.productmanagement.productmain;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.hlag.productmanagement.entity.Product;
import com.hlag.productmanagement.service.ProductService;
import com.hlag.productmanagement.service.ProductServiceImpl;

public class ProductManagementApp {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ProductService service = ProductServiceImpl.getInstance();

		while (true) {
			// Display the menu
			System.out.println("Product Management System:");
			System.out.println("1. Add Product");
			System.out.println("2. View Products");
			System.out.println("3. Update Product");
			System.out.println("4. Delete Product");
			System.out.println("5. Retrive Product With Sorting");
			System.out.println("6. Exit");
			System.out.print("Enter your choice (1-6): ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
				case 1: // Add Product
					System.out.print("Enter product name: ");
					String name = scanner.nextLine();
					System.out.print("Enter product description: ");
					String description = scanner.nextLine();
					System.out.print("Enter product price: ");
					double price = scanner.nextDouble();
					System.out.print("Enter product quantity: ");
					int quantity = scanner.nextInt();
					scanner.nextLine();
					Product newProduct = new Product(name, description, price, quantity);
					Product addedProduct = service.addProduct(newProduct);
					System.out.println("Product added with ID: " + addedProduct.getProductId());
					break;

				case 2: // View Products
					Optional<List<Product>> products = service.getProducts();
					if (products.isPresent() && !products.get().isEmpty()) {
						System.out.println("List of Products:");
						for (Product product : products.get()) {
							System.out.println(product);
						}
					} else {
						System.out.println("No products available.");
					}
					break;

				case 3: // Update Product
					System.out.print("Enter product ID to update: ");
					String updateProductId = scanner.nextLine();
					Optional<Product> existingProduct = service.getProductById(updateProductId);
					if (existingProduct.isPresent()) {
						System.out.print("Enter new product name: ");
						String updatedName = scanner.nextLine();
						System.out.print("Enter new product description: ");
						String updatedDescription = scanner.nextLine();
						System.out.print("Enter new product price: ");
						double updatedPrice = scanner.nextDouble();
						System.out.print("Enter new product quantity: ");
						int updatedQuantity = scanner.nextInt();
						scanner.nextLine();
						Product updatedProduct = new Product(updatedName, updatedDescription, updatedPrice, updatedQuantity);
						service.updateProduct(updateProductId, updatedProduct);
						System.out.println("Product updated.");
					} else {
						System.out.println("Product not found.");
					}
					break;

				case 4: // Delete Product
					System.out.print("Enter product ID to delete: ");
					String deleteProductId = scanner.nextLine();
					boolean deleted = service.deleteProduct(deleteProductId);
					if (deleted) {
						System.out.println("Product deleted successfully.");
					} else {
						System.out.println("Product not found.");
					}
					break;

				case 5:
					// Retrieve products without any sorting
					List<Product> products1 = service.getAllProduct();
					if (products1.isEmpty()) {
						System.out.println("No products available.");
					} else {
						System.out.println("List of Products:");
						for (Product product : products1) {
							System.out.println(product);
						}
					}
					break;

				case 6: // Exit
					System.out.println("Exiting Product Management System.");
					scanner.close();
					return;
				default:
					System.out.println("Invalid choice.");
			}
		}
	}
}
