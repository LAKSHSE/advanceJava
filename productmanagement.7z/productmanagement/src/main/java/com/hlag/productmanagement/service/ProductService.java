package com.hlag.productmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hlag.productmanagement.entity.Product;

public interface ProductService {

	public Product addProduct(Product product);

	public Optional<Product> getProductById(String id);

	public Optional<List<Product>> getProducts();

	public boolean deleteProduct(String id);

	public Product updateProduct(String id, Product product);

	public List<Product> getProductsSortedByName();

	public List<Product> getProductsSortedByPrice();

	public List<Product> getAllProduct();
}
