package com.hlag.productmanagement.entity;

import java.util.UUID;

public class Product {

	private UUID productId;
	private String name;
	private String description;
	private double price;
	private int stock;

	public Product(String name, String description, double price, int stock) {
		super();
		this.productId = UUID.randomUUID();
		this.name = name;
		this.description = description;
		this.price = price;
		this.stock = stock;
	}

	// Getters and setters
	public UUID getProductId() {
		return productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", stock=" + stock + "]";
	}

}
