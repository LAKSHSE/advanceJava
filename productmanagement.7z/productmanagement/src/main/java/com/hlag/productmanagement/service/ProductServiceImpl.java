package com.hlag.productmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hlag.productmanagement.entity.Product;
import com.hlag.productmanagement.repo.ProductRepository;
import com.hlag.productmanagement.repo.ProductRepositoryImpl;

public class ProductServiceImpl implements ProductService {

	private ProductRepository productRepository = ProductRepositoryImpl.getInstance();
	private static ProductServiceImpl productServiceImpl;

	private ProductServiceImpl() {

	}

	public static ProductServiceImpl getInstance() {
		if (productServiceImpl == null) {
			productServiceImpl = new ProductServiceImpl();
		}
		return productServiceImpl;
	}

	@Override
	public Product addProduct(Product product) {
		return productRepository.addProduct(product);
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return productRepository.getProductById(id);
	}

	@Override
	public Optional<List<Product>> getProducts() {
		return productRepository.getProducts();
	}

	@Override
	public boolean deleteProduct(String id) {
		return productRepository.deleteProduct(id);
	}

	@Override
	public Product updateProduct(String id, Product product) {
		return productRepository.updateProduct(id, product);
	}

	@Override
	public List<Product> getProductsSortedByName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductsSortedByPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProduct() {
		return productRepository.getAllProduct();
	}

}
