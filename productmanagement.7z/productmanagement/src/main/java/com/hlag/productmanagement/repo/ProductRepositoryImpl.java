package com.hlag.productmanagement.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.hlag.productmanagement.entity.Product;

public class ProductRepositoryImpl implements ProductRepository {

	private List<Product> products = new ArrayList<>();
	private static ProductRepositoryImpl productRepositoryImpl;

	private ProductRepositoryImpl() {
	}

	public static ProductRepositoryImpl getInstance() {
		if (productRepositoryImpl == null) {
			productRepositoryImpl = new ProductRepositoryImpl();
		}
		return productRepositoryImpl;

	}

	@Override
	public Product addProduct(Product product) {
		return products.add(product) ? product : null;
	}

	@Override
	public Optional<Product> getProductById(String id) {
		return products.stream().filter(e -> e.getProductId().toString().equals(id)).findFirst();
	}

	@Override
	public Optional<List<Product>> getProducts() {
		return products.isEmpty() ? Optional.empty() : Optional.of(new ArrayList<>(products));
	}

	@Override
	public boolean deleteProduct(String id) {
		Optional<Product> product = getProductById(id);
		if (product.isPresent()) {
			products.remove(product.get());
			return true;
		}
		return false;
	}

	@Override
	public Product updateProduct(String id, Product updatedProduct) {
		Optional<Product> existingProduct = getProductById(id);
		if (existingProduct.isPresent()) {
			Product product = existingProduct.get();
			product.setName(updatedProduct.getName());
			product.setDescription(updatedProduct.getDescription());
			product.setPrice(updatedProduct.getPrice());
			product.setStock(updatedProduct.getStock());
			return product;
		}
		return null;
	}

	@Override
	public List<Product> getProductsSortedByName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getProductsSortedByPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProduct() {
		return products;
	}

}
