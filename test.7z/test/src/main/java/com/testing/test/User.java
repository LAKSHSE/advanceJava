package com.testing.test;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.testing.test.exception.InvalidNameException;

public class User extends InvalidNameException {

	private static final long serialVersionUID = 1L;
	private UUID id;
	private String username;
	private String password;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String email;

	public User(String username, String password, String firstName, String lastName, String phoneNumber, String email)
			throws InvalidNameException {
		super();
		this.id = UUID.randomUUID();
		setUsername(username);
		setPassword(password);
		setFirstName(firstName);
		setLastName(lastName);
		setPhoneNumber(phoneNumber);
		setEmail(email);
	}

	public UUID getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		if (username != null && username.length() <= 8) {
			this.username = username;
		} else {
			throw new IllegalArgumentException("Username is invalid.Please use correct username");
		}
	}

	public String getPassword() {
		return password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName != null && firstName.length() == 2) {
			this.firstName = firstName;
		} else {
			throw new IllegalArgumentException("First Name is Less than 3.Please Check FirstName Character");
		}
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		if (lastName != null && lastName.length() <= 2) {
			this.lastName = lastName;
		} else {
			throw new IllegalArgumentException("Last Name is Less than 3.Please Check Last Name Character");
		}
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		// Define the regex pattern for a valid phone number
		String regex = "^(\\+\\d{1,3}[- ]?)?\\d{10}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(phoneNumber);

		// Validate the phone number
		if (matcher.matches()) {
			this.phoneNumber = phoneNumber;
		} else {
			throw new IllegalArgumentException("Invalid phone number format");
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		if (isValidEmail(email)) {
			this.email = email;
		} else {
			throw new IllegalArgumentException("Invalid email format");
		}
	}

	private boolean isValidEmail(String email) {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		return email.matches(emailRegex);
	}

	public void setPassword(String password) {
		if (isValidPassword(password)) {
			this.password = password;
		} else {
			throw new IllegalArgumentException("Password does not meet the required criteria.");
		}
	}

	private boolean isValidPassword(String password) {
		// Password must be at least 8 characters long
		if (password.length() < 8) {
			return false;
		}
		// Password must contain at least one uppercase letter
		if (!password.matches(".*[A-Z].*")) {
			return false;
		}
		// Password must contain at least one lowercase letter
		if (!password.matches(".*[a-z].*")) {
			return false;
		}
		// Password must contain at least one digit
		if (!password.matches(".*\\d.*")) {
			return false;
		}
		// Password must contain at least one special character
		if (!password.matches(".*[@#$%^&+=].*")) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", password=" + password + "]";
	}
}