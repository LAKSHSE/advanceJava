package com.testing.test.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.testing.test.User;
import com.testing.test.exception.InvalidNameException;

public class UserRepositoryImpl implements UserRepository {

	private Set<User> users = new HashSet<>();
	private static UserRepositoryImpl userRepositoryImpl;

	private UserRepositoryImpl() {
	}

	public static UserRepositoryImpl getInstance() {
		synchronized (UserRepositoryImpl.class) {
		if (userRepositoryImpl == null) {
			userRepositoryImpl = new UserRepositoryImpl();
		}
	}
		return userRepositoryImpl;

	}

	@Override
	public User addUser(User user) {
		boolean result = users.add(user);
		if (result) {
			return user;
		}
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		UUID uuid = UUID.fromString(id);
		// for (User user : users) {
		// if (user.getUuid().equals(uuid)) {
		// return Optional.of(user);
		// }
		// }
		// return Optional.empty();
		return users.stream().filter(e -> e.getId().toString().equals(id)).findFirst();
	}

	@Override
	public Optional<List<User>> getUsers() {
		if (users.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.of(new ArrayList<>(users));
		}
	}

	@Override
	public void deleteUser(String id) {
		UUID uuid = UUID.fromString(id);
		users.removeIf(user -> user.getId().equals(uuid));
	}

	@Override
	public User updateUser(String id, User user) throws InvalidNameException {
		// for (User user1 : users) {
		// // if (user1.getId().equals(id)) {
		// // user1.updateFromEntity(
		// // user.getUserName(),
		// // user.getFirstName(),
		// // user.getLastName(),
		// // user.getEmail(),
		// // user.getPassword());
		// // }
		// throw new IllegalArgumentException("User records not updated");
		// }
		return user;
	}

	public static void main(String[] args) {
		Runnable run = () -> {
			UserRepositoryImpl userRepositoryImpl = getInstance();
			System.out.println(userRepositoryImpl.hashCode());
			System.out.println(userRepositoryImpl.hashCode());

		};

		Thread t = new Thread(run);
		t.start();
		Thread t2 = new Thread(run);
		t2.start();
		Thread t3 = new Thread(run);
		t3.start();
	}

}
