package com.testing.test;


public class Concrete extends AbstractTest {

	@Override
	public void method8() {
		System.out.println("method 8");
	}

	@Override
	public void method9() {
		System.out.println("method 9");
	}

	public static void main(String[] args) {
		I1 i1 = new Concrete();
		i1.method1();

		I2 i2 = new Concrete();
		i2.method5();
	}

}
