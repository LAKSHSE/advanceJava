package com.testing.test.service;

import java.util.List;
import java.util.Optional;

import javax.naming.InvalidNameException;

import com.testing.test.User;
import com.testing.test.repo.UserRepository;
import com.testing.test.repo.UserRepositoryImpl;

public class UserServiceImpl implements UserService {

	private UserRepository userRepository = UserRepositoryImpl.getInstance();
	private static UserServiceImpl userServiceImpl;

	private UserServiceImpl() {
	}

	public static UserServiceImpl getInstance() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserServiceImpl();
		}
		return userServiceImpl;

	}
	@Override
	public User addUser(User user) {
		return userRepository.addUser(user);
	}

	@Override
	public Optional<User> getUserById(String id) {
		return userRepository.getUserById(id);
	}

	@Override
	public Optional<List<User>> getUsers() {
		return userRepository.getUsers();
	}

	@Override
	public void deleteUser(String id) {
		userRepository.deleteUser(id);
	}

	@Override
	public User updateUser(String id, User user)
			throws InvalidNameException, com.testing.test.exception.InvalidNameException {
		return userRepository.updateUser(id, user);
	}

}
