package com.testing.test.subtest;

import com.testing.test.User;

public class SubTest {

	public static void main(String[] args) {
		User test = new User();
		test.setUsername("dyjkllwo");
		test.setFirstName("sf");
		test.setLastName("klsdfb");
		System.out.println("output of the above setters:" + test.getUsername());
		System.out.println("output of the above setters:" + test.getFirstName());
		System.out.println("output of the above setters:" + test.getLastName());
	}
}
