package com.testing.test;


public abstract class AbstractTest implements I1, I2, I3 {

	@Override
	public void method5() {
		System.out.println("method 5");
	}

	@Override
	public void method6() {
		System.out.println("method 6");
	}

	@Override
	public void method7() {
		System.out.println("method 7");
	}

	@Override
	public void method1() {
		System.out.println("method 1");
	}

	@Override
	public void method2() {
		System.out.println("method 2");
	}

	@Override
	public void method3() {
		System.out.println("method 3");
	}

	@Override
	public void method4() {
		System.out.println("method 4");
	}

	public static void main(String[] args) {
		I3 i3 = new Concrete();
		i3.method8();
	}
}
