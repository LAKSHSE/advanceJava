package com.testing.test;

import java.util.List;
import java.util.Optional;

import com.testing.test.exception.InvalidNameException;
import com.testing.test.service.UserService;
import com.testing.test.service.UserServiceImpl;

public class AppTest {

	private static final String CREATE = "CREATE";
	private static final String RETRIVE_BY_ID = "RETRIVE_BY_ID";
	private static final String RETRIVE_ALL = "RETRIVE_ALL";
	private static final String UPDATE = "UPDATE";
	private static final String DELETE = "DELETE";
	private static final String OPERATION = "OPERATION";

	public static void main(String[] args) throws javax.naming.InvalidNameException {
		UserService userService = UserServiceImpl.getInstance();
		User user = null;
		try {
			switch (OPERATION) {
				case CREATE:
					user = new User("Jafru@1131", "SK", "Jafrulla", "9160266986", "jafrusk10@gmail.com", null);
					userService.addUser(user);
					if (user != null) {
						System.out.println("User created successfully ");
					}
				case RETRIVE_BY_ID:
					Optional<User> user2 = userService.getUserById(user.getId().toString());
					if (user2.isPresent()) {
						System.out.println("No record");
					} else {
						System.out.println("Get user by id : " + user2);
					}
				case RETRIVE_ALL:
					Optional<List<User>> user3 = userService.getUsers();
					System.out.println("User list " + user3);
				case UPDATE:
					User user4 = userService.updateUser(
							user.getId().toString(),
							new User("Jafru@1132", "SK", "Jafru", "9160266966", "jafrusk@gmail.com", null));
					System.out.println("Updated User --- " + user4);
				case DELETE:
					userService.deleteUser(user.getId().toString());
				default:
					break;
			}

		} catch (InvalidNameException e) {
			e.getMessage();
		}

	}

}
