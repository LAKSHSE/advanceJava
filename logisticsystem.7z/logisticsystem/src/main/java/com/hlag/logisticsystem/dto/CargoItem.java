package com.hlag.logisticsystem.dto;


public class CargoItem {

	private double weight;
	private String dimensions;
	private String type;

	public CargoItem(double weight, String dimensions, String type) {
		super();
		this.weight = weight;
		this.dimensions = dimensions;
		this.type = type;
	}

	public double getWeight() {
		return weight;
	}

	public String getDimensions() {
		return dimensions;
	}

	public String getType() {
		return type;
	}

	public double calculateShippingCost() {
		double costPerKg = 5.0; // Base rate per kg
		if (this.type.equalsIgnoreCase("fragile")) {
			costPerKg += 2.0; // Additional cost for fragile items
		}

		// Shipping cost is weight multiplied by rate per kg
		return weight * costPerKg;
	}

}
