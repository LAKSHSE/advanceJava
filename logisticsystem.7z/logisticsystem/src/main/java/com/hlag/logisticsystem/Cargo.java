package com.hlag.logisticsystem;

import com.hlag.logisticsystem.dto.CargoItem;

public class Cargo {

	public static void main(String[] args) {
		// Create some cargo items
		CargoItem item1 = new CargoItem(10.0, "50x30x20 cm", "standard");
		CargoItem item2 = new CargoItem(5.5, "30x20x15 cm", "fragile");

		// Print the details and shipping costs
		System.out.println(item1);
		System.out.println(item2);
	}

}
