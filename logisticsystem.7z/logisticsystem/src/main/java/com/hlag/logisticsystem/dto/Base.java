package com.hlag.logisticsystem.dto;


public class Base {

	int value;
	int value1;

	protected Base(int value, int value1) {
		this.value = value;
		this.value1 = value1;
	}

	// public Base() {
	// }

	public static void test() {
		System.out.println("Base class");
	}
}
