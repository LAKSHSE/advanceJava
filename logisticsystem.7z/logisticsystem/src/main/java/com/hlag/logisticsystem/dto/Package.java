package com.hlag.logisticsystem.dto;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class Package {

	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestones;

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getMilestones() {
		return Collections.unmodifiableList(milestones);
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		}
		this.weight = weight;
	}

	public void markAsDelivered(String status) {
		// in transist
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("package is in transists");
		}
		this.status = "delivered";
		this.milestones.add("delivered on" + LocalDate.now());
		// delivered @so :so date so:so time
	}

	public String getTrackingId() {
		return trackingId;
	}

	// public Package(String trackingId, String destination, double weight) {
	// super();
	// this.trackingId = trackingId;//
	// this.destination = destination;
	// this.status = "In Transit"; // Initial status
	// this.milestones = new ArrayList<>();
	// setWeight(weight);
	// }

	// public Package() {
	// this.trackingId = "";
	// // Default Constructor
	// }

	private Package() {
		this.trackingId = "";
		// Default Constructor
	}

	private static Package pack;

	public static Package getInstance() {
		if (pack == null) {
			pack = new Package();
		}
		return pack;
	}
}
