package com.hlag.logisticsystem;

import com.hlag.logisticsystem.dto.Base;

public class Derived extends Base {

	// int value;
	// int value1;

	// public Derived() {
	// }

	// public Derived(int value, int value1) {
	// this.value = value;
	// this.value1 = value1;
	// }

	public Derived() {
		super(10, 10);
	}

	public static void test() {
		System.out.println("Derived Class");
	}
}
