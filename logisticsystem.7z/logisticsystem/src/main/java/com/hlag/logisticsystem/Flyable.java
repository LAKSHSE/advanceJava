package com.hlag.logisticsystem;


public interface Flyable {

	public static void fly() {
		System.out.println("IronMan Fly method called");
	}

}
