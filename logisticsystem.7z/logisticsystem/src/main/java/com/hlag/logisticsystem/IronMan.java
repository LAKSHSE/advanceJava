package com.hlag.logisticsystem;


public class IronMan implements Flyable {

	public static void fly() {
		System.out.println("IronMan Fly method called");
	}

	public void car() {
		System.out.println("Car to drive the all places");
	}

}
