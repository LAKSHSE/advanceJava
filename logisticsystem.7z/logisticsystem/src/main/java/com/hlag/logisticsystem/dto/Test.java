package com.hlag.logisticsystem.dto;

import com.hlag.logisticsystem.Flyable;
import com.hlag.logisticsystem.IronMan;

public class Test {

	public static void main(String[] args) {

		Flyable flyable = new IronMan();
		Flyable.fly();

		IronMan ironMan = new IronMan();
		ironMan.fly();
	}

}
