package com.hlag.logisticsystem;

import com.hlag.logisticsystem.dto.Base;

public class Derived2 extends Base {

}
